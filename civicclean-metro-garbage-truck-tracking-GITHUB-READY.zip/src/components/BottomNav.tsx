import React from 'react';
import { Home, Navigation, Calendar, AlertTriangle, LayoutDashboard } from 'lucide-react';
import { ScreenId } from './Sidebar';
import { UserRole } from '../types';

interface BottomNavProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  userRole: UserRole;
  isSeniorMode: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentScreen,
  onNavigate,
  userRole,
  isSeniorMode,
}) => {
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 text-slate-300">
      <div className="grid grid-cols-5 h-16 items-center px-1">
        <button
          onClick={() => onNavigate('citizen_home')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            currentScreen === 'citizen_home' ? 'text-emerald-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5 mb-1" />
          <span className={`${isSeniorMode ? 'text-xs' : 'text-[10px]'} truncate`}>Home</span>
        </button>

        <button
          onClick={() => onNavigate('live_tracking')}
          className={`relative flex flex-col items-center justify-center h-full transition-colors ${
            currentScreen === 'live_tracking' ? 'text-emerald-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span className="relative">
            <Navigation className="w-5 h-5 mb-1 text-emerald-400" />
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
          </span>
          <span className={`${isSeniorMode ? 'text-xs' : 'text-[10px]'} truncate`}>Track Live</span>
        </button>

        <button
          onClick={() => onNavigate('schedule')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            currentScreen === 'schedule' ? 'text-emerald-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-5 h-5 mb-1" />
          <span className={`${isSeniorMode ? 'text-xs' : 'text-[10px]'} truncate`}>Schedule</span>
        </button>

        <button
          onClick={() => onNavigate('report_issue')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            currentScreen === 'report_issue' ? 'text-emerald-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <AlertTriangle className="w-5 h-5 mb-1" />
          <span className={`${isSeniorMode ? 'text-xs' : 'text-[10px]'} truncate`}>Report</span>
        </button>

        <button
          onClick={() => onNavigate(userRole === 'citizen' ? 'admin_dashboard' : 'fleet_management')}
          className={`flex flex-col items-center justify-center h-full transition-colors ${
            currentScreen === 'admin_dashboard' || currentScreen === 'fleet_management' || currentScreen === 'analytics'
              ? 'text-sky-400 font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <LayoutDashboard className="w-5 h-5 mb-1" />
          <span className={`${isSeniorMode ? 'text-xs' : 'text-[10px]'} truncate`}>
            {userRole === 'admin' ? 'Fleet' : 'Portal'}
          </span>
        </button>
      </div>
    </nav>
  );
};
