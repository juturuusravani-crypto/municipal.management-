import React from 'react';
import { 
  Home, 
  Navigation, 
  Calendar, 
  AlertTriangle, 
  Bell, 
  LayoutDashboard, 
  Truck, 
  BarChart3, 
  ShieldCheck, 
  Info,
  ChevronRight,
  Sparkles,
  PhoneCall,
  UserCheck
} from 'lucide-react';
import { UserRole } from '../types';

export type ScreenId = 
  | 'login'
  | 'citizen_home'
  | 'live_tracking'
  | 'schedule'
  | 'report_issue'
  | 'notifications'
  | 'admin_dashboard'
  | 'fleet_management'
  | 'analytics';

interface SidebarProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  userRole: UserRole;
  isSeniorMode: boolean;
  unreadNotificationsCount: number;
  openComplaintsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  userRole,
  isSeniorMode,
  unreadNotificationsCount,
  openComplaintsCount,
}) => {
  const citizenNavItems: { id: ScreenId; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'citizen_home', label: 'Citizen Home', icon: <Home className="w-5 h-5" /> },
    { id: 'live_tracking', label: 'Live Truck Tracking', icon: <Navigation className="w-5 h-5" />, badge: 'LIVE' },
    { id: 'schedule', label: 'Collection Schedule', icon: <Calendar className="w-5 h-5" /> },
    { id: 'report_issue', label: 'Report Missed/Overflow', icon: <AlertTriangle className="w-5 h-5" />, badge: openComplaintsCount > 0 ? openComplaintsCount : undefined },
    { id: 'notifications', label: 'Notifications & Alerts', icon: <Bell className="w-5 h-5" />, badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : undefined },
  ];

  const municipalNavItems: { id: ScreenId; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'admin_dashboard', label: 'Command Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'fleet_management', label: 'Trucks & Drivers', icon: <Truck className="w-5 h-5" /> },
    { id: 'analytics', label: 'Analytics & Reports', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col justify-between shrink-0 min-h-[calc(100vh-4rem)]">
      <div className="p-4 space-y-6">
        {/* Role Indicator Banner */}
        <div className="p-3 rounded-lg bg-slate-800/80 border border-slate-700/80">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Viewing Portal As</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
              userRole === 'admin' 
                ? 'bg-sky-950 text-sky-300 border border-sky-800' 
                : userRole === 'driver' 
                ? 'bg-amber-950 text-amber-300 border border-amber-800'
                : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
            }`}>
              {userRole === 'admin' ? 'Officer / Admin' : userRole === 'driver' ? 'Driver Staff' : 'Resident Citizen'}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-300 font-medium truncate">
            {userRole === 'admin' ? 'Central Fleet Control' : userRole === 'driver' ? 'Assigned: Truck GT-104' : 'Ward 4 - Green Meadows'}
          </p>
        </div>

        {/* Citizen Services Nav */}
        <div>
          <div className="px-2 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Citizen Services
          </div>
          <nav className="space-y-1">
            {citizenNavItems.map((item) => {
              const isActive = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition-colors ${
                    isActive
                      ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  } ${isSeniorMode ? 'text-base py-3' : 'text-sm'}`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-white' : 'text-emerald-400'}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      isActive 
                        ? 'bg-emerald-800 text-white' 
                        : item.badge === 'LIVE'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-700 animate-pulse'
                        : 'bg-rose-900/80 text-rose-300'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Municipal Staff & Fleet Operations */}
        <div>
          <div className="px-2 mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Municipal Staff Fleet</span>
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <nav className="space-y-1">
            {municipalNavItems.map((item) => {
              const isActive = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition-colors ${
                    isActive
                      ? 'bg-sky-600 text-white font-semibold shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  } ${isSeniorMode ? 'text-base py-3' : 'text-sm'}`}
                >
                  <div className="flex items-center gap-3">
                    <span className={isActive ? 'text-white' : 'text-sky-400'}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Auth / Screen Switcher */}
        <div>
          <button
            onClick={() => onNavigate('login')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
              currentScreen === 'login'
                ? 'bg-slate-700 text-white font-medium'
                : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            } text-xs`}
          >
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-slate-400" />
              <span>Login / Account Switcher</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
          </button>
        </div>
      </div>

      {/* Bottom Civic Helpline Box */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/60">
        <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold mb-1">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>24/7 Waste Helpline</span>
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Missed truck or urgent spillage emergency?
          </p>
          <div className="mt-2 text-white font-mono font-bold tracking-wider text-xs bg-slate-800 px-2 py-1 rounded inline-block">
            1800-CLEAN-MUNI
          </div>
        </div>
      </div>
    </aside>
  );
};
