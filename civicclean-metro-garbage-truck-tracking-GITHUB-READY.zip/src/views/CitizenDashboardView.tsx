import React, { useState } from 'react';
import { 
  Navigation, 
  MapPin, 
  Clock, 
  Truck, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  Phone, 
  ArrowRight, 
  Volume2, 
  ShieldCheck, 
  Leaf, 
  Recycle, 
  Sparkles,
  HelpCircle,
  BellRing
} from 'lucide-react';
import { Truck as TruckType, Ward, UserProfile, WasteType } from '../types';
import { WASTE_TYPES_INFO } from '../data/mockData';
import { ScreenId } from '../components/Sidebar';

interface CitizenDashboardViewProps {
  currentUser: UserProfile;
  currentWard: Ward;
  nearbyTruck: TruckType;
  onNavigate: (screen: ScreenId) => void;
  isSeniorMode: boolean;
  onToggleSeniorMode: () => void;
}

export const CitizenDashboardView: React.FC<CitizenDashboardViewProps> = ({
  currentUser,
  currentWard,
  nearbyTruck,
  onNavigate,
  isSeniorMode,
}) => {
  const [buzzerEnabled, setBuzzerEnabled] = useState(true);
  const [voicePlaying, setVoicePlaying] = useState(false);

  const triggerVoiceUpdate = () => {
    setVoicePlaying(true);
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(
        `Hello ${currentUser.name}. Today is Organic Green Bin day. Truck ${nearbyTruck.truckNumber} is approaching and estimated to arrive in ${nearbyTruck.estimatedArrivalMinutes} minutes.`
      );
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
    setTimeout(() => setVoicePlaying(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Welcome & Location Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/60 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>Sanitation Service Active Today</span>
            </div>
            <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
              Good Morning, {currentUser.name.split(' ')[0]}
            </h1>
            <div className="flex items-center gap-2 mt-1 text-slate-300 text-xs sm:text-sm">
              <MapPin className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="font-medium text-white">{currentUser.address}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-400">{currentWard.name}</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={triggerVoiceUpdate}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all ${
                voicePlaying
                  ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
              title="Voice announcement of arrival status"
            >
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <span>{voicePlaying ? 'Announcing...' : 'Audio Announcement'}</span>
            </button>

            <button
              onClick={() => onNavigate('live_tracking')}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md shadow-emerald-950 transition-all cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
              <span>Track Live Truck</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Hero: Nearby Truck & Today's Collection Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Real-Time Truck Card */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-700/60 flex items-center justify-center text-emerald-400">
                  <Truck className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-white">Truck {nearbyTruck.truckNumber}</h2>
                    <span className="px-2 py-0.5 text-[11px] font-bold rounded bg-emerald-950 text-emerald-300 border border-emerald-700">
                      ON ROUTE
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Driver: {nearbyTruck.driverName} · Helper: {nearbyTruck.helperName}
                  </p>
                </div>
              </div>

              {/* ETA Display */}
              <div className="text-right">
                <div className="text-xs text-slate-400 font-medium uppercase tracking-wider">Estimated Arrival</div>
                <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
                  ~{nearbyTruck.estimatedArrivalMinutes} MINS
                </div>
                <div className="text-[11px] text-slate-400">
                  Approx. {nearbyTruck.distanceMeters}m away
                </div>
              </div>
            </div>

            {/* Stepper Progress Bar */}
            <div className="my-6">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2">
                <span>Route Progress to Your Street</span>
                <span className="text-emerald-400 font-mono">Stop 5 of 8</span>
              </div>

              {/* 4 Step Pipeline */}
              <div className="grid grid-cols-4 gap-2">
                <div className="flex flex-col">
                  <div className="h-2 rounded bg-emerald-500 mb-1.5"></div>
                  <span className="text-[11px] font-semibold text-white">1. Dispatched</span>
                  <span className="text-[10px] text-slate-400">08:30 AM (Depot)</span>
                </div>
                <div className="flex flex-col">
                  <div className="h-2 rounded bg-emerald-500 mb-1.5"></div>
                  <span className="text-[11px] font-semibold text-white">2. Sector Route</span>
                  <span className="text-[10px] text-slate-400">Maple Ln cleared</span>
                </div>
                <div className="flex flex-col">
                  <div className="h-2 rounded bg-amber-400 animate-pulse mb-1.5"></div>
                  <span className="text-[11px] font-semibold text-amber-300">3. Approaching</span>
                  <span className="text-[10px] text-amber-400 font-medium">Your Street Next</span>
                </div>
                <div className="flex flex-col">
                  <div className="h-2 rounded bg-slate-800 mb-1.5"></div>
                  <span className="text-[11px] font-medium text-slate-400">4. Collected</span>
                  <span className="text-[10px] text-slate-400">Final Verification</span>
                </div>
              </div>
            </div>

            {/* Preparation Reminder */}
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/50 flex items-start gap-3 text-xs text-emerald-200">
              <Leaf className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white">Green Bin Pickup Active: </span>
                Please place wet kitchen waste, food scraps, and vegetable peels curbside before 09:40 AM. Lid must be securely shut.
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                <input
                  type="checkbox"
                  checked={buzzerEnabled}
                  onChange={(e) => setBuzzerEnabled(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 bg-slate-800 border-slate-700"
                />
                <BellRing className="w-3.5 h-3.5 text-amber-400" />
                <span>Buzz device when truck is 2 minutes away</span>
              </label>
            </div>

            <button
              onClick={() => onNavigate('live_tracking')}
              className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 transition-colors"
            >
              <span>Open Full Interactive GPS Map</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Col: Ward Information & Quick Helpline */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Ward Information</h3>
              <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                {currentWard.zone.split(' ')[0]}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Ward Name</span>
                <span className="font-semibold text-slate-200">{currentWard.name}</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Sanitation Inspector</span>
                <span className="font-semibold text-slate-200">{currentWard.inspectorName}</span>
                <span className="text-slate-400 block font-mono text-[11px]">{currentWard.inspectorPhone}</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Active Waste Trucks Today</span>
                <span className="font-semibold text-emerald-400">{currentWard.activeTruckCount} Trucks operating in sector</span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Today's Ward Collection Rate</span>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-emerald-500 h-full rounded-full" 
                      style={{ width: `${currentWard.completionRate}%` }}
                    ></div>
                  </div>
                  <span className="font-mono text-xs font-bold text-white">{currentWard.completionRate}%</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 space-y-2">
            <button
              onClick={() => onNavigate('report_issue')}
              className="w-full py-2 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>Report Missed Bin / Issue</span>
            </button>

            <button
              onClick={() => onNavigate('schedule')}
              className="w-full py-2 px-3 rounded-lg bg-slate-800/60 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <Calendar className="w-3.5 h-3.5 text-sky-400" />
              <span>View Full Weekly Schedule</span>
            </button>
          </div>
        </div>
      </div>

      {/* Waste Segregation Guide Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white">Waste Segregation Rules</h2>
            <p className="text-xs text-slate-400">Clean city guidelines for your neighborhood bins</p>
          </div>
          <button
            onClick={() => onNavigate('schedule')}
            className="text-xs text-emerald-400 font-semibold hover:underline"
          >
            Check Schedule Table →
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {WASTE_TYPES_INFO.map((item) => (
            <div
              key={item.type}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    item.color === 'emerald'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : item.color === 'sky'
                      ? 'bg-sky-950 text-sky-300 border border-sky-800'
                      : item.color === 'amber'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-purple-950 text-purple-300 border border-purple-800'
                  }`}>
                    {item.binColor}
                  </span>
                </div>
                <h3 className="font-bold text-white text-sm mb-2">{item.label}</h3>
                <ul className="text-xs text-slate-300 space-y-1 mb-3">
                  {item.items.map((sub, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <span className="w-1 h-1 rounded-full bg-slate-500"></span>
                      <span>{sub}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 italic">
                {item.instruction}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
