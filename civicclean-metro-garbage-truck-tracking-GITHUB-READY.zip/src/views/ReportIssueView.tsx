import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Camera, 
  MapPin, 
  Send, 
  CheckCircle2, 
  Clock, 
  FileText, 
  Upload, 
  Image as ImageIcon,
  ShieldCheck,
  ChevronRight,
  Sparkles,
  Info
} from 'lucide-react';
import { Complaint, ComplaintType, Ward, UserProfile } from '../types';
import { COMPLAINTS, WARDS } from '../data/mockData';

interface ReportIssueViewProps {
  currentUser: UserProfile;
  currentWard: Ward;
  isSeniorMode: boolean;
}

export const ReportIssueView: React.FC<ReportIssueViewProps> = ({
  currentUser,
  currentWard,
  isSeniorMode,
}) => {
  const [complaintList, setComplaintList] = useState<Complaint[]>(COMPLAINTS);
  const [complaintType, setComplaintType] = useState<ComplaintType>('missed_collection');
  const [locationAddress, setLocationAddress] = useState<string>(currentUser.address);
  const [description, setDescription] = useState<string>('');
  const [urgency, setUrgency] = useState<'low' | 'medium' | 'high'>('medium');
  const [selectedPhoto, setSelectedPhoto] = useState<string>(
    'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80'
  );
  const [activeTab, setActiveTab] = useState<'new_report' | 'track_status'>('new_report');
  const [submittedTicket, setSubmittedTicket] = useState<Complaint | null>(null);

  // Sample photo presets for quick realistic testing
  const photoPresets = [
    { label: 'Overflowing Bin', url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80' },
    { label: 'Skipped Curbside', url: 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=600&q=80' },
    { label: 'Damaged Plastic Lid', url: 'https://images.unsplash.com/photo-1595278069441-2cf29f8005a4?auto=format&fit=crop&w=600&q=80' },
    { label: 'Illegal Road Debris', url: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?auto=format&fit=crop&w=600&q=80' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newId = `CCM-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newComplaint: Complaint = {
      id: `cmp-${Date.now()}`,
      ticketNumber: newId,
      citizenName: currentUser.name,
      citizenPhone: currentUser.phone,
      wardId: currentWard.id,
      wardName: currentWard.name,
      locationAddress,
      complaintType,
      description: description || 'Report submitted via citizen mobile app.',
      urgency,
      status: 'submitted',
      submittedAt: 'Just now',
      updatedAt: 'Just now',
      photoUrl: selectedPhoto,
    };

    setComplaintList([newComplaint, ...complaintList]);
    setSubmittedTicket(newComplaint);
    setActiveTab('track_status');
    setDescription('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Report Waste & Sanitation Issues
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Submit missed collections, overflowing bins, or spillage for rapid municipal resolution
          </p>
        </div>

        {/* Tab switch buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-800 rounded-xl border border-slate-700">
          <button
            onClick={() => setActiveTab('new_report')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'new_report'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            File New Report
          </button>
          <button
            onClick={() => setActiveTab('track_status')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'track_status'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>My Reports</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-900 text-[10px] font-bold text-emerald-400">
              {complaintList.length}
            </span>
          </button>
        </div>
      </div>

      {submittedTicket && activeTab === 'track_status' && (
        <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/80 shadow-md flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">
                Complaint Registered Successfully! Ticket #{submittedTicket.ticketNumber}
              </h3>
              <p className="text-xs text-emerald-300">
                Dispatched to Ward 4 Sanitation Inspector Sanjay Deshmukh. SLA resolution in 4 hours.
              </p>
            </div>
          </div>
          <button
            onClick={() => setSubmittedTicket(null)}
            className="text-xs text-slate-400 hover:text-white px-2 py-1"
          >
            Dismiss
          </button>
        </div>
      )}

      {activeTab === 'new_report' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Form */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Type Selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  1. Issue Category
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { type: 'missed_collection', label: 'Missed Pickup', desc: 'Curbside bin skipped' },
                    { type: 'overflowing_bin', label: 'Overflowing Bin', desc: 'Waste spilling on sidewalk' },
                    { type: 'damaged_bin', label: 'Damaged Bin', desc: 'Broken wheels or lid' },
                    { type: 'illegal_dumping', label: 'Illegal Dumping', desc: 'Debris left in public zone' },
                    { type: 'spillage', label: 'Truck Spillage', desc: 'Waste fell from vehicle' },
                    { type: 'driver_issue', label: 'Staff / Service Feedback', desc: 'Crew assistance required' },
                  ].map((cat) => (
                    <button
                      key={cat.type}
                      type="button"
                      onClick={() => setComplaintType(cat.type as ComplaintType)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        complaintType === cat.type
                          ? 'bg-emerald-950/60 border-emerald-500 text-white ring-1 ring-emerald-500'
                          : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span className="font-bold text-xs block text-white">{cat.label}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{cat.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Location Input */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    2. Location & Address
                  </label>
                  <button
                    type="button"
                    onClick={() => setLocationAddress(currentUser.address)}
                    className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                  >
                    <MapPin className="w-3 h-3" />
                    <span>Use My Residence GPS</span>
                  </button>
                </div>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                  <input
                    type="text"
                    value={locationAddress}
                    onChange={(e) => setLocationAddress(e.target.value)}
                    placeholder="Enter street name, landmark, or bin number"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              {/* Photo Upload Simulation */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  3. Upload Photo Evidence
                </label>
                <div className="space-y-3">
                  {/* Preset Photo Selectors */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {photoPresets.map((preset, idx) => (
                      <div
                        key={idx}
                        onClick={() => setSelectedPhoto(preset.url)}
                        className={`cursor-pointer rounded-lg overflow-hidden border transition-all ${
                          selectedPhoto === preset.url
                            ? 'border-emerald-400 ring-2 ring-emerald-400'
                            : 'border-slate-700 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={preset.url}
                          alt={preset.label}
                          className="h-16 w-full object-cover"
                        />
                        <div className="p-1 bg-slate-800 text-[10px] text-center text-slate-300 truncate">
                          {preset.label}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Selected Photo Preview */}
                  {selectedPhoto && (
                    <div className="p-2 bg-slate-800/60 rounded-xl border border-slate-700 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img
                          src={selectedPhoto}
                          alt="Evidence preview"
                          className="w-10 h-10 rounded-lg object-cover border border-slate-600"
                        />
                        <span className="text-xs text-slate-300">Photo attached for sanitation inspector</span>
                      </div>
                      <span className="text-xs text-emerald-400 font-semibold">✓ Verified</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Urgency Level */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  4. Urgency Priority
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { level: 'low', label: 'Routine (24 hrs)' },
                    { level: 'medium', label: 'Normal (8 hrs)' },
                    { level: 'high', label: 'Urgent (Within 4 hrs)' },
                  ].map((p) => (
                    <button
                      key={p.level}
                      type="button"
                      onClick={() => setUrgency(p.level as any)}
                      className={`py-2 px-3 rounded-lg border text-xs font-semibold transition-all ${
                        urgency === p.level
                          ? 'bg-slate-700 border-white text-white shadow-sm'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  5. Detailed Description (Optional)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  placeholder="Provide any additional details (e.g., bin handle broken, dog scavengers, lane blocked)..."
                  className="w-full p-3 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                ></textarea>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className={`w-full py-3 px-4 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition-all ${
                  isSeniorMode ? 'text-lg py-4' : 'text-sm'
                }`}
              >
                <Send className="w-4 h-4" />
                <span>Submit Grievance to Municipal Authority</span>
              </button>
            </form>
          </div>

          {/* Quick Help & SLA Info */}
          <div className="space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <ShieldCheck className="w-4 h-4" />
                <span>Municipal Citizen Charter</span>
              </div>
              <div className="space-y-3 text-xs text-slate-300">
                <div>
                  <span className="font-semibold text-white block">Missed Collection SLA:</span>
                  <span className="text-slate-400">Standby mini-lifter dispatched within 4 hours of verification.</span>
                </div>
                <div>
                  <span className="font-semibold text-white block">Bin Repair / Replacement:</span>
                  <span className="text-slate-400">Damaged bins swapped within 48 business hours.</span>
                </div>
                <div>
                  <span className="font-semibold text-white block">Official Escalation:</span>
                  <span className="text-slate-400">Reports auto-escalate to Chief Sanitation Officer if untouched in 6 hours.</span>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
              <h4 className="font-bold text-white text-sm mb-2">Direct Phone Escalation</h4>
              <p className="text-xs text-slate-400 mb-3">
                Prefer to speak to an officer directly? Call your Ward 4 control room.
              </p>
              <div className="p-2.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white font-mono flex items-center justify-between">
                <span>{currentWard.inspectorPhone}</span>
                <span className="text-[10px] text-emerald-400 uppercase font-semibold">Toll Free</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Track Complaints Tab */
        <div className="space-y-4">
          {complaintList.map((ticket) => (
            <div
              key={ticket.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all shadow-sm"
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  {ticket.photoUrl && (
                    <img
                      src={ticket.photoUrl}
                      alt="Complaint photo"
                      className="w-20 h-20 rounded-xl object-cover border border-slate-700 shrink-0"
                    />
                  )}
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-emerald-400">
                        {ticket.ticketNumber}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        ticket.status === 'resolved'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : ticket.status === 'in_progress'
                          ? 'bg-sky-950 text-sky-300 border border-sky-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {ticket.status.replace('_', ' ')}
                      </span>
                      <span className="text-xs text-slate-500">·</span>
                      <span className="text-xs text-slate-400 capitalize">{ticket.complaintType.replace('_', ' ')}</span>
                    </div>

                    <h3 className="font-bold text-white text-base mt-1">
                      {ticket.locationAddress}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {ticket.description}
                    </p>

                    {ticket.assignedStaff && (
                      <p className="text-[11px] text-slate-400 mt-2 font-medium">
                        Assigned To: <span className="text-slate-200">{ticket.assignedStaff}</span>
                      </p>
                    )}

                    {ticket.resolutionNotes && (
                      <div className="mt-3 p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-200">
                        <span className="font-bold text-white">Resolution Note: </span>
                        {ticket.resolutionNotes}
                      </div>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs text-slate-400 block font-medium">Reported</span>
                  <span className="text-xs text-slate-200 font-mono">{ticket.submittedAt}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
