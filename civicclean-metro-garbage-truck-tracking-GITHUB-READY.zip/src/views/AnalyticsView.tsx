import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  Truck, 
  Users, 
  FileSpreadsheet,
  ArrowUpRight,
  Filter
} from 'lucide-react';
import { Ward, FleetStats } from '../types';

interface AnalyticsViewProps {
  stats: FleetStats;
  wards: Ward[];
  isSeniorMode: boolean;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  stats,
  wards,
  isSeniorMode,
}) => {
  const [timeframe, setTimeframe] = useState<'today' | 'week' | 'month'>('week');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Daily tonnage data (Mon to Sun)
  const dailyTonnage = [
    { day: 'Mon', tons: 48.5, target: 45 },
    { day: 'Tue', tons: 44.2, target: 45 },
    { day: 'Wed', tons: 46.8, target: 45 },
    { day: 'Thu', tons: 42.1, target: 45 },
    { day: 'Fri', tons: 51.3, target: 45 },
    { day: 'Sat', tons: 53.0, target: 45 },
    { day: 'Sun', tons: 28.4, target: 30 },
  ];

  const handleExport = (format: 'pdf' | 'csv') => {
    setExportNotice(`Generated Municipal_Waste_Report_${format.toUpperCase()}`);
    setTimeout(() => setExportNotice(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className={`font-extrabold text-white tracking-tight ${isSeniorMode ? 'text-3xl' : 'text-2xl'}`}>
            Municipal Sanitation Analytics & KPIs
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Data intelligence on waste segregation compliance, route efficiency, and citizen grievance resolution
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('csv')}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => handleExport('pdf')}
            className="px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-md shadow-sky-950 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Official PDF Report</span>
          </button>
        </div>
      </div>

      {exportNotice && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-500/80 rounded-xl text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{exportNotice} successfully downloaded to your device.</span>
          </div>
        </div>
      )}

      {/* Top Telemetry Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Weekly Tonnage</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">314.3 Tons</div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 mt-2 font-medium">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+4.2% higher recycling diversion rate</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">On-Time Arrival Rate</span>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-1">94.8%</div>
          <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-2">
            <span>±4 mins of timetable estimate</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Missed Collection Rate</span>
          <div className="text-2xl font-extrabold text-sky-400 font-mono mt-1">0.18%</div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 mt-2 font-medium">
            <span>Well below 0.5% municipal tolerance</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Grievance SLA Speed</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono mt-1">2.4 Hours</div>
          <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-2">
            <span>Target response &lt; 4 hours</span>
          </div>
        </div>
      </div>

      {/* Visual Chart 1: Daily Collection Tonnage & Target */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-white text-base">Daily Collection Tonnage (Metric Tons)</h3>
              <p className="text-xs text-slate-400">Total wet and dry waste hauled across city sectors</p>
            </div>
            <span className="text-xs text-emerald-400 font-mono font-bold">Goal: 45T / day</span>
          </div>

          {/* SVG Bar Chart */}
          <div className="h-56 w-full flex items-end justify-between gap-3 pt-6 pb-2 px-2">
            {dailyTonnage.map((item) => {
              const maxTons = 60;
              const heightPercent = (item.tons / maxTons) * 100;
              const isToday = item.day === 'Mon';

              return (
                <div key={item.day} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <span className="text-[10px] font-mono text-slate-400 font-semibold">{item.tons}T</span>
                  <div className="w-full max-w-[36px] bg-slate-800 rounded-t-lg overflow-hidden flex items-end h-full">
                    <div
                      className={`w-full rounded-t-lg transition-all ${
                        isToday
                          ? 'bg-emerald-500 shadow-lg shadow-emerald-500/20'
                          : 'bg-emerald-700/80 hover:bg-emerald-600'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    ></div>
                  </div>
                  <span className={`text-xs font-semibold ${isToday ? 'text-white' : 'text-slate-400'}`}>
                    {item.day}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Visual Chart 2: Ward-Wise Completion Efficiency */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-white text-base">Ward Route Coverage Efficiency</h3>
              <p className="text-xs text-slate-400">Percentage of target households serviced today</p>
            </div>
          </div>

          <div className="space-y-3.5 pt-2">
            {wards.map((ward) => (
              <div key={ward.id} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{ward.name}</span>
                  <span className="text-white font-mono font-bold">{ward.completionRate}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      ward.completionRate >= 90
                        ? 'bg-emerald-500'
                        : ward.completionRate >= 80
                        ? 'bg-sky-500'
                        : 'bg-amber-500'
                    }`}
                    style={{ width: `${ward.completionRate}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Grid: Complaint Categories & Fleet Fuel Efficiency */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Complaints Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
          <h3 className="font-bold text-white text-base pb-2 border-b border-slate-800">
            Citizen Grievance Types
          </h3>
          <div className="space-y-2 text-xs">
            {[
              { type: 'Overflowing Public Bin', count: 18, share: '42%' },
              { type: 'Missed Curbside Lane', count: 12, share: '28%' },
              { type: 'Damaged Bin / Lid', count: 8, share: '19%' },
              { type: 'Road Spillage / Illegal Dump', count: 5, share: '11%' },
            ].map((c, i) => (
              <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-slate-800/60">
                <span className="text-slate-300">{c.type}</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-white font-bold">{c.count}</span>
                  <span className="text-slate-500 text-[10px]">({c.share})</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fleet Fuel & Green Vehicle Ratio */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
          <h3 className="font-bold text-white text-base pb-2 border-b border-slate-800">
            Clean Fleet Transition
          </h3>
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/50">
              <span className="text-emerald-400 font-bold block text-sm">68% EV / Bio-Methane Fleet</span>
              <p className="text-slate-400 mt-1">19 out of 28 operational compactors run on zero direct emissions.</p>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Diesel Consumption:</span>
              <span className="text-white font-mono">-18.4% vs last quarter</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span>Carbon Offset:</span>
              <span className="text-emerald-400 font-mono font-bold">142 MT CO2e saved</span>
            </div>
          </div>
        </div>

        {/* Citizen Satisfaction Index */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
          <h3 className="font-bold text-white text-base pb-2 border-b border-slate-800">
            Citizen Satisfaction Score
          </h3>
          <div className="flex items-center gap-4 py-2">
            <div className="text-4xl font-extrabold text-amber-400 font-mono">4.84</div>
            <div>
              <div className="flex text-amber-400 text-sm">★★★★★</div>
              <span className="text-[11px] text-slate-400 mt-0.5 block">Based on 1,420 monthly citizen ratings</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Highest satisfaction recorded in Ward 4 Green Meadows (4.92) due to real-time truck arrival push notifications.
          </p>
        </div>
      </div>
    </div>
  );
};
