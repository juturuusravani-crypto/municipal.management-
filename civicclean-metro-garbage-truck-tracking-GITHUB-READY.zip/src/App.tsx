import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, ScreenId } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { LoginView } from './views/LoginView';
import { CitizenDashboardView } from './views/CitizenDashboardView';
import { LiveTrackingView } from './views/LiveTrackingView';
import { ScheduleView } from './views/ScheduleView';
import { ReportIssueView } from './views/ReportIssueView';
import { NotificationsView } from './views/NotificationsView';
import { AdminDashboardView } from './views/AdminDashboardView';
import { FleetManagementView } from './views/FleetManagementView';
import { AnalyticsView } from './views/AnalyticsView';
import { 
  WARDS, 
  DEMO_USERS, 
  TRUCKS as initialTrucks, 
  NOTIFICATIONS as initialNotifications, 
  FLEET_STATS, 
  COMPLAINTS 
} from './data/mockData';
import { UserProfile, UserRole, Ward, Truck, CivicNotification, TruckStatus } from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile>(DEMO_USERS[0]); // Sarah Jenkins (citizen)
  const [currentWard, setCurrentWard] = useState<Ward>(WARDS[0]); // Ward 4
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('citizen_home');
  const [trucks, setTrucks] = useState<Truck[]>(initialTrucks);
  const [selectedTruck, setSelectedTruck] = useState<Truck>(initialTrucks[0]);
  const [notifications, setNotifications] = useState<CivicNotification[]>(initialNotifications);
  const [isSeniorMode, setIsSeniorMode] = useState<boolean>(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Switch active ward
  const handleSelectWard = (ward: Ward) => {
    setCurrentWard(ward);
    const wardTruck = trucks.find((t) => t.wardId === ward.id) || trucks[0];
    setSelectedTruck(wardTruck);
  };

  // Switch demo user
  const handleSwitchUserRole = (role: UserRole) => {
    const user = DEMO_USERS.find((u) => u.role === role) || DEMO_USERS[0];
    setCurrentUser(user);
    if (role === 'admin') {
      setCurrentScreen('admin_dashboard');
    } else if (role === 'driver') {
      const driverTruck = trucks.find((t) => t.driverName.includes('Marcus')) || trucks[0];
      setSelectedTruck(driverTruck);
      setCurrentScreen('live_tracking');
    } else {
      setCurrentScreen('citizen_home');
    }
  };

  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      setCurrentScreen('admin_dashboard');
    } else if (user.role === 'driver') {
      setCurrentScreen('live_tracking');
    } else {
      setCurrentScreen('citizen_home');
    }
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleMarkAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleBroadcastAlert = (title: string, message: string, wardId: string) => {
    const newAlert: CivicNotification = {
      id: `alert-${Date.now()}`,
      type: 'emergency',
      title,
      message,
      timestamp: 'Just now',
      read: false,
      wardId: wardId === 'all' ? undefined : wardId,
      priority: 'high',
    };
    setNotifications([newAlert, ...notifications]);
  };

  const handleAddTruck = (newTruck: Truck) => {
    setTrucks([newTruck, ...trucks]);
  };

  const handleUpdateTruckStatus = (id: string, status: TruckStatus) => {
    setTrucks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status } : t))
    );
    if (selectedTruck.id === id) {
      setSelectedTruck((prev) => ({ ...prev, status }));
    }
  };

  // Close mobile drawer upon navigation
  const handleNavigate = (screen: ScreenId) => {
    setCurrentScreen(screen);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col ${isSeniorMode ? 'text-base' : 'text-sm'}`}>
      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        currentWard={currentWard}
        allWards={WARDS}
        onSelectWard={handleSelectWard}
        isSeniorMode={isSeniorMode}
        onToggleSeniorMode={() => setIsSeniorMode(!isSeniorMode)}
        notifications={notifications}
        onOpenNotifications={() => handleNavigate('notifications')}
        onSwitchUser={handleSwitchUserRole}
        onOpenMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Main Layout Container */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Desktop Sidebar (hidden on mobile, visible on lg screens) */}
        {currentScreen !== 'login' && (
          <div className="hidden lg:block shrink-0">
            <Sidebar
              currentScreen={currentScreen}
              onNavigate={handleNavigate}
              userRole={currentUser.role}
              isSeniorMode={isSeniorMode}
              unreadNotificationsCount={notifications.filter((n) => !n.read).length}
              openComplaintsCount={COMPLAINTS.filter((c) => c.status !== 'resolved').length}
            />
          </div>
        )}

        {/* Mobile Navigation Drawer Modal */}
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex">
            <div className="w-72 bg-slate-900 border-r border-slate-800 p-4 flex flex-col justify-between h-full overflow-y-auto">
              <div>
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
                  <span className="font-extrabold text-white text-base">CivicClean Menu</span>
                  <button
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="p-1 rounded-md text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                </div>
                <Sidebar
                  currentScreen={currentScreen}
                  onNavigate={handleNavigate}
                  userRole={currentUser.role}
                  isSeniorMode={isSeniorMode}
                  unreadNotificationsCount={notifications.filter((n) => !n.read).length}
                  openComplaintsCount={COMPLAINTS.filter((c) => c.status !== 'resolved').length}
                />
              </div>
            </div>
            <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)}></div>
          </div>
        )}

        {/* Main Content Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 pb-24 lg:pb-12 min-w-0 overflow-x-hidden">
          {currentScreen === 'login' && (
            <LoginView
              onLoginSuccess={handleLoginSuccess}
              isSeniorMode={isSeniorMode}
              onToggleSeniorMode={() => setIsSeniorMode(!isSeniorMode)}
            />
          )}

          {currentScreen === 'citizen_home' && (
            <CitizenDashboardView
              currentUser={currentUser}
              currentWard={currentWard}
              nearbyTruck={selectedTruck}
              onNavigate={handleNavigate}
              isSeniorMode={isSeniorMode}
              onToggleSeniorMode={() => setIsSeniorMode(!isSeniorMode)}
            />
          )}

          {currentScreen === 'live_tracking' && (
            <LiveTrackingView
              currentTruck={selectedTruck}
              allTrucks={trucks}
              onSelectTruck={(t) => setSelectedTruck(t)}
              currentUser={currentUser}
              currentWard={currentWard}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'schedule' && (
            <ScheduleView
              currentWard={currentWard}
              allWards={WARDS}
              onSelectWard={handleSelectWard}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'report_issue' && (
            <ReportIssueView
              currentUser={currentUser}
              currentWard={currentWard}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'notifications' && (
            <NotificationsView
              notifications={notifications}
              onMarkAsRead={handleMarkAsRead}
              onMarkAllAsRead={handleMarkAllAsRead}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'admin_dashboard' && (
            <AdminDashboardView
              stats={FLEET_STATS}
              trucks={trucks}
              wards={WARDS}
              selectedTruck={selectedTruck}
              onSelectTruck={(t) => setSelectedTruck(t)}
              onNavigate={handleNavigate}
              onBroadcastAlert={handleBroadcastAlert}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'fleet_management' && (
            <FleetManagementView
              trucks={trucks}
              wards={WARDS}
              onAddTruck={handleAddTruck}
              onUpdateTruckStatus={handleUpdateTruckStatus}
              isSeniorMode={isSeniorMode}
            />
          )}

          {currentScreen === 'analytics' && (
            <AnalyticsView
              stats={FLEET_STATS}
              wards={WARDS}
              isSeniorMode={isSeniorMode}
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      {currentScreen !== 'login' && (
        <BottomNav
          currentScreen={currentScreen}
          onNavigate={handleNavigate}
          userRole={currentUser.role}
          isSeniorMode={isSeniorMode}
        />
      )}
    </div>
  );
}
